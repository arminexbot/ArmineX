export const getReferral = (req, res) => {
    res.json({
        referralCode: "armineX_123456789",
        invited: 0
    });
};